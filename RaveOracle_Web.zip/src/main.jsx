import React from 'react';
import ReactDOM from 'react-dom/client';
import RaveOracleApp from './RaveOracleApp';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RaveOracleApp />
  </React.StrictMode>
);
